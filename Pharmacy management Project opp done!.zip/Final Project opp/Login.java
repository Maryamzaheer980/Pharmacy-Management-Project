/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pharmacymanagementsystem1;

/**
 *
 * @author hp
 */

import java.awt.event.*;


public class LoginDashboard {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String username = "admin";
        String password = "123";

        System.out.println("===== PHARMACY MANAGEMENT SYSTEM =====");

        System.out.print("Username: ");
        String user = sc.nextLine();

        System.out.print("Password: ");
        String pass = sc.nextLine();

        if(user.equals(username) && pass.equals(password)) {

            System.out.println("Login Successful");

            int choice;

            do {

                System.out.println("\n===== DASHBOARD =====");

                System.out.println("1. Medicine Management");
                System.out.println("2. Company Management");
                System.out.println("3. Agent Management");
                System.out.println("4. Billing Management");
                System.out.println("5. Exit");

                System.out.print("Enter Choice: ");

                choice = sc.nextInt();

                switch(choice) {

                    case 1:
                        System.out.println("Medicine Module");
                        break;

                    case 2:
                        System.out.println("Company Module");
                        break;

                    case 3:
                        System.out.println("Agent Module");
                        break;

                    case 4:
                        System.out.println("Billing Module");
                        break;

                    case 5:
                        System.out.println("Thank You");
                        break;

                    default:
                        System.out.println("Invalid Choice");
                }

            } while(choice != 5);

        } else {

            System.out.println("Invalid Login");
        }
    }
}