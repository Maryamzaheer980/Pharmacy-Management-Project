/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pharmacymanagementsystem1;

/**
 *
 * @author hp
 */
public class PharmacyManagementSystem1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
