/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pharmacymanagementsystem1;

/**
 *
 * @author hp
 */
    public class Agent {

    private int agentId;
    private String agentName;
    private String phone;

    public Agent(int agentId,
                 String agentName,
                 String phone) {

        this.agentId = agentId;
        this.agentName = agentName;
        this.phone = phone;
    }

    public int getAgentId() {
        return agentId;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    @Override
    public String toString() {

        return agentId + " "
                + agentName + " "
                + phone;
    }
}
}
