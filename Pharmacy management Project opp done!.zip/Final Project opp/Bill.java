/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pharmacymanagementsystem1;

/**
 *
 * @author hp
 */
    public class Bill {

    private int billId;
    private String customerName;
    private double totalAmount;

    public Bill(int billId,
                String customerName,
                double totalAmount) {

        this.billId = billId;
        this.customerName = customerName;
        this.totalAmount = totalAmount;
    }

    public int getBillId() {
        return billId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    @Override
    public String toString() {

        return billId + " "
                + customerName + " "
                + totalAmount;
    }
}
}
